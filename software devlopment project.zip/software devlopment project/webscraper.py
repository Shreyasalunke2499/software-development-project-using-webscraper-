import requests
from bs4 import BeautifulSoup
import csv
import sqlite3
from datetime import date

class VergeWebScraper:
def __init__(self, url):
self.url = url
self.data = []

deffetch_data(self):
        response = requests.get(self.url)
        soup = BeautifulSoup(response.content, 'html.parser')
        articles = soup.find_all('article')

        for article in articles:
            headline = article.find('h2').text.strip()
            link = article.find('a')['href']
            author = article.find('span', class_='c-byline__author').text.strip()
date_published = article.find('time')['datetime'].split('T')[0]
self.data.append((headline, link, author, date_published))

defsave_csv(self):
        filename = date.today().strftime('%d%m%Y') + '_verge.csv'
        with open(filename, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
writer.writerow(['id', 'URL', 'headline', 'author', 'date'])
            for idx, (headline, link, author, date_published) in enumerate(self.data):
writer.writerow([idx, link, headline, author, date_published])

defsave_sqlite(self):
        conn = sqlite3.connect('verge.db')
        c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS articles
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
url TEXT,
                      headline TEXT,
                      author TEXT,
                      date TEXT)''')

        for headline, link, author, date_published in self.data:
c.execute("INSERT INTO articles (url, headline, author, date) VALUES (?, ?, ?, ?)",
                      (link, headline, author, date_published))
conn.commit()
conn.close()

if __name__ == '__main__':
    scraper = VergeWebScraper('https://www.theverge.com/')
scraper.fetch_data()
scraper.save_csv()
scraper.save_sqlite()
